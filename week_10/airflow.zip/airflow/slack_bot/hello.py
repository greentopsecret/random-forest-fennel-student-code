'''
This is just a placeholder file for the slack_bot script that you are going
to write in the afternoon.
'''
import logging
import time

while True:
    logging.critical("\nTweeting the newest tweet!\n")
    time.sleep(10)
